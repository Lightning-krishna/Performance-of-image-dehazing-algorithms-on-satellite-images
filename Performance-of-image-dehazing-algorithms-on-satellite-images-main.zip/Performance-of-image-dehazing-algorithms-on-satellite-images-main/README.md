# Performance-of-image-dehazing-algorithms-on-satellite-images
This is a project which shows the performance of existing image dehazing algorithms on satellite images.
The file 'Report.pdf' explains the project and performance scores of various existing state-of-the art image dehazing algorithms on satellite images. 
We have implemented a new method to add haze to images so that we can get a reference image for using the evaluation metrics on the dataset.

Follow for more updates on this project.
