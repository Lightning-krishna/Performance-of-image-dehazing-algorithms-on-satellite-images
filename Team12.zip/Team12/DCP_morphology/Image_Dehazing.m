close all;

%input image
for i=1:5

    input_image_filename = fullfile(['C://Users//manis//Documents//Research//data//normal//normal_' num2str(i) '.jpg']);
    input_image = imread(input_image_filename);
    input_image2 = imresize(input_image,[256 256]);
    input_image2 = double(input_image2);
    %Show Original
    %figure('Name','Original');
    %imshow(uint8(input_image));

    %Finding DCP using gray scale erosion
    DCP = morphologyDCP(input_image2,'square',15);
    size(input_image2)
    %Finding atmospheric light
    AtmostpherLight = atmostphericLight(input_image2,DCP);

    %Normalising input image based on atmospheric light
    normalizedInput = normalizeImage(input_image2,AtmostpherLight);

    minimalChannel = minimumChannel(normalizedInput);

    t1 = initialTransMap(minimalChannel);

    %performing closing morphological reconstruction
    t2 = closingRecontruction(t1,'square',15);

    %performing opening morphological reconstruction
    t3 = openingRecontruction(t2,'square',15);

    %Removing small obejects in the environment
    R = removedSmallObjects(t1,t3);

    %Recovering ranges of values original for the original transmissions
    t3_prime = recoverRanges(t1,t3);

    %Refining the Transmission map
    t_morf = refineTransmissionMap(t3_prime,R)

    %Dehazing
    dehazed_img = removeHaze(input_image2, t_morf, AtmostpherLight);
    %figure('name','dehazed');
    %imshow(uint8(dehazed_img));
    imwrite(uint8(dehazed_img),['C://Users//manis//Documents//Research//data//output_images//DCP_normal_' num2str(i) '.jpg'])

end